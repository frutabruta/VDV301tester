#include "spoj.h"

Spoj::Spoj()
{

}
