#ifndef XMLMPVPARSER_H
#define XMLMPVPARSER_H


class xmlMPVparser
{
public:
    xmlMPVparser();
};

#endif // XMLMPVPARSER_H
