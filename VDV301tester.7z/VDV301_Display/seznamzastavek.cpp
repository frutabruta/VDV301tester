#include "seznamzastavek.h"

SeznamZastavek::SeznamZastavek()
{
}
