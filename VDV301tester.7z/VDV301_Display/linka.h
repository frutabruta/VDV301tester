#ifndef LINKA_H
#define LINKA_H

#include <QObject>
#include <QWidget>

class Linka
{
public:
    Linka();
    int c=0;
    int lc=0;
    QString n="";
};

#endif // LINKA_H
