#include "xmlmpvparser.h"

xmlMPVparser::xmlMPVparser()
{





}
