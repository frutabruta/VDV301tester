#include "linka.h"

Linka::Linka()
{

}
