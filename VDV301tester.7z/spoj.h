#ifndef SPOJ_H
#define SPOJ_H

#include <QObject>
#include <QWidget>

class Spoj
{
public:
    Spoj();
    int cislo=0;
    int cisloRopid=0;
};

#endif // SPOJ_H
