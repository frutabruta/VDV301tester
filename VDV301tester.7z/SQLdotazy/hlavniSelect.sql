SELECT z.n, x.o FROM x LEFT JOIN s ON x.s_id=s.s LEFT JOIN z ON x.u = z.u AND x.z=z.z LEFT JOIN l ON s.l=l.c WHERE l.lc=290664 AND s.c=6003

SELECT z.n, x.o,z.cis FROM x LEFT JOIN s ON x.s_id=s.s LEFT JOIN z ON x.u = z.u AND x.z=z.z LEFT JOIN l ON s.l=l.c WHERE l.lc=290664 AND s.c=6003 AND  s.kj LIKE '1%' ORDER BY x.o


4012
100311

