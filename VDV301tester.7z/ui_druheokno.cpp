#include "ui_druheokno.h"
#include "mainwindow.h"
#include "ui_mainwindow.h"


ui_druheokno::ui_druheokno(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::ui_druheokno)
{

    ui->setupUi(this);

}
